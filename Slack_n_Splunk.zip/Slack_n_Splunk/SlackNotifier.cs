﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Slack.Webhooks;
using Microsoft.Extensions.Logging;


namespace Slack_n_Splunk
{
    public class SlackNotifier
    {
        private readonly ILogger _logger;

        public SlackNotifier(ILogger logger)
        {
            _logger = logger;
        }

        public void NotifySlack(string webhookUrl)
        {
            var client = new SlackClient(webhookUrl);

            var message = new SlackMessage
            {
                Text = "New message from Slack_n_Splunk app"
            };

            client.Post(message);

            // Use the logging method here
            var loggerInstance = new InstanceLoggingExample(_logger);
            loggerInstance.CouldNotOpenSocket("localhost");

            // You can also log the activity context here if needed
            using (var activity = new System.Diagnostics.Activity("SlackNotification"))
            {
                activity.SetTag("WebhookUrl", webhookUrl);
                activity.Start();

                _logger.LogInformation("Sent a Slack message to {webhookUrl}", webhookUrl);

                activity.Stop();
            }
        }
    }
}
